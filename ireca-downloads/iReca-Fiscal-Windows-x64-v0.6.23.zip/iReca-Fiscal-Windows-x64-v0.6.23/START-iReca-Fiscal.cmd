@echo off
setlocal
cd /d "%~dp0"
if /i "%PROCESSOR_ARCHITECTURE%"=="AMD64" goto architecture_ok
if /i "%PROCESSOR_ARCHITEW6432%"=="AMD64" goto architecture_ok
echo Acest pachet necesita Windows x64 pe procesor Intel/AMD.
echo Nu este o versiune pentru Windows 32-bit sau ARM.
pause
exit /b 1
:architecture_ok
set "frameworkRelease=0"
for /f "tokens=3" %%R in ('reg query "HKLM\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" /v Release /reg:64 2^>nul') do set /a frameworkRelease=%%R
if %frameworkRelease% GEQ 528040 goto runtime_ok
echo .NET Framework 4.8 sau o versiune 4.x ulterioara nu a fost detectata.
echo Sursa oficiala: https://dotnet.microsoft.com/en-us/download/dotnet-framework/net48
echo Nu s-a instalat nimic. Verificati Windows si instructiunile CITESTE-MA.txt.
echo Windows 8.0 NU suporta .NET Framework 4.8. Nu incercati instalarea lui pe Windows 8.0.
pause
exit /b 2
:runtime_ok
if not exist "iRecaFiscal.exe" (
 echo Extrageti mai intai intreaga arhiva, apoi deschideti START-iReca-Fiscal.cmd.
 pause
 exit /b 3
)
start "" "%~dp0iRecaFiscal.exe"
exit /b 0
