iReca Fiscal 0.6.23 - corectie citire identitate inainte de copia JE

Cererea de copie #2 pentru comanda 115 a fost respinsa inainte de tiparire.
Metadatele serverului confirma print_attempted=false, document_selected=false
si device_matched=false. Apelul de identificare 90 din workerul de copie
trimitea un parametru gol; citirea Datecs validata trimite un TAB. Workerul
foloseste acum aceeasi definitie canonica a comenzii ca citirea obisnuita.

Raspunsul acceptat pentru comanda 90 ramane strict: 9 campuri separate prin
TAB, inclusiv ultimul camp gol dupa TAB-ul final; codul din primul camp este
0, modelul este DP-150MX, seria corespunde identitatii conexiunii DUDE si
amprentei bonului original. Sunt verificate si formatul firmware-ului, al
datei, al orei si al octetilor de stare. Un raspuns incomplet sau diferit
este respins; nu se ajunge la selectarea documentului ori la tiparire.
Mesajul de eroare arata forma asteptata fara serie sau raspuns brut.
Octetii raspunsului real din cererea #2 nu au fost pastrati in rezultatul
serverului, asa ca forma lor exacta nu poate fi afirmata retrospectiv.

Nu exista retrimitere automata. Cererile #1 si #2 raman esuate si nu sunt
reluate de instalarea acestui pachet. O proba fizica noua necesita o cerere
explicita si verificarea rezultatului pe hartie si in Jurnalul Electronic.

Instalare: inchideti iReca Fiscal pe PC-ul separat de test, pastrati o copie
a folderului aplicatiei si a datelor locale, apoi copiati continutul pachetului
peste instalarea 0.6.22. Nu stergeti folderul data. Porniti o singura instanta
si verificati ca versiunea raportata este 0.6.23. Acest pachet nu schimba
V4, POS sau configuratia fiscala a casei.

Validare locala: verificari cu driver simulat, fara comanda de tiparire pe
aparatul fizic. Formatul raspunsului a fost confirmat prin calea de citire
existenta; apelul gresit din copie a fost corectat. Jurnalul local Windows
al PC-ului separat de test nu este prezent in acest pachet.
